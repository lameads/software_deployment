# safeguard_deployments
Includes the deployment files for software, not including the vpn configuration files, for deploying on our machines. Updated as of 1/9/25.

NOTE: For deploying the capture machine, use the deployment_guide.txt file. Do not use old_setup.txt or compilation_notes.txt. 

compilation_notes.txt just explains some parts of how compilation works with library dependencies and the differences between statically linking and dynamically linking external libraries and the benefits and drawbacks of each.
